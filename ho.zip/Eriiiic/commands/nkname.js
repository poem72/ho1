const { MessageAttachment } = require('discord.js');
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description React to a specific message using its link and a given emoji.
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command
 */
module.exports.reactToMessage = async (client, message, args) => {
    try {
        const logChannel = client.channels.cache.get('1284204173772062815'); // Error/debugging log channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send("You don't have permission to use this command.");
        }

        // Ensure link and emoji are provided
        if (args.length < 2) {
            return message.channel.send("Please provide a message link and an emoji.");
        }

        // Extract message link and emoji
        const [link, emoji] = args;
        const messageId = link.split('/').pop(); // Extract message ID from link

        // Validate emoji
        if (!emoji) {
            return message.channel.send("Please provide a valid emoji.");
        }

        // Fetch the message
        const msg = await message.channel.messages.fetch(messageId);

        // React to the message
        await msg.react(emoji);
        message.channel.send(`**Reacted with ${emoji} to the message** <${link}>`);

        // Log the reaction
        logChannel?.send(`Reacted with ${emoji} to message ${messageId}: ${link}`); // Log reaction

    } catch (error) {
        console.error("Error occurred while reacting to the message:", error);

        // Log the error in the log channel and send an error message to the original channel
        const logChannel = client.channels.cache.get('1284204173772062815');
        logChannel?.send(`Error occurred while reacting to the message: \`\`\`${error.message}\`\`\``);
        message.channel.send("An error occurred while reacting to the message.");
    }
};

module.exports.names = {
    list: ["like"]
};
