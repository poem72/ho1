const fs = require('fs');
const fastWords = require("../cut.json");
const allowedUsers = require("../allowed.json").allowed;

// A map to track active channels and their corresponding emojis
const activeChannels = new Map();

/**
 * @description Start reacting to new messages in a specified channel after 30 seconds and ignore bot messages.
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        const logChannel = client.channels.cache.get('1284204173772062815'); // Error/debugging log channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            return //message.channel.send("You don't have permission to use this command.");
        }

        // Ensure channel and emoji are provided
        if (args.length < 2) {
            return message.channel.send("Please provide a text channel and an emoji.");
        }

        // Validate the provided channel
        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            logChannel?.send(`Invalid channel: ${args[0]}`); // Log invalid channel
            return message.channel.send("Please provide a valid text channel.");
        }

        // Validate the provided emoji
        const emoji = args[1];
        if (!emoji) {
            logChannel?.send(`Invalid emoji: ${args[1]}`); // Log invalid emoji
            return message.channel.send("Please provide a valid emoji.");
        }

        // Notify the user that the event has started
        message.channel.send(`**Starting to react with ${emoji} in** ${channel.toString()}`);

        // Check if the channel is already being monitored
        if (activeChannels.has(channel.id)) {
            return message.channel.send("This channel is already being monitored.");
        }

        // Add channel to active channels map
        activeChannels.set(channel.id, emoji);

        // Reaction handler
        const reactionHandler = async (msg) => {
            if (msg.author.bot) return; // Ignore bot messages

            setTimeout(async () => {
                try {
                    await msg.react(emoji);
                    logChannel?.send(`Reacted with ${emoji} to message: ${msg.id}`); // Log reaction
                } catch (error) {
                    console.error("Error reacting to message:", error);
                    logChannel?.send(`Failed to react to message ${msg.id}: \`\`\`${error.message}\`\`\``); // Log error
                }
            }, 30000); // React 30 seconds after message is sent
        };

        // Listen to messages in the channel
        client.on('messageCreate', (msg) => {
            if (msg.channel.id === channel.id) {
                reactionHandler(msg);
            }
        });

    } catch (error) {
        console.error("Error occurred during the event:", error);

        // Log the error in the log channel and send an error message to the original channel
        const logChannel = client.channels.cache.get('1284204173772062815');
        logChannel?.send(`Error occurred during the reaction event: \`\`\`${error.message}\`\`\``);
        message.channel.send("An error occurred while starting the event.");
    }
};

/**
 * @description Stop reacting to messages in a specified channel.
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command
 */
module.exports.stop = async (client, message, args) => {
    try {
        const logChannel = client.channels.cache.get('1284204173772062815'); // Error/debugging log channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            return //message.channel.send("You don't have permission to use this command.");
        }

        // Ensure channel is provided
        if (args.length < 1) {
            return message.channel.send("Please provide a text channel.");
        }

        // Validate the provided channel
        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            logChannel?.send(`Invalid channel: ${args[0]}`); // Log invalid channel
            return message.channel.replay("👎");
        }

        // Check if the channel is being monitored
        if (!activeChannels.has(channel.id)) {
            return message.channel.send("This channel is not being monitored.");
        }

        // Remove channel from active channels map
        activeChannels.delete(channel.id);

        message.channel.send(`**Stopped reacting to messages in** ${channel.toString()}`);
        logChannel?.send(`Stopped monitoring channel: ${channel.id}`); // Log stop event

    } catch (error) {
        console.error("Error occurred while stopping the event:", error);

        // Log the error in the log channel and send an error message to the original channel
        const logChannel = client.channels.cache.get('1284204173772062815');
        logChannel?.send(`Error occurred while stopping the reaction event: \`\`\`${error.message}\`\`\``);
        message.channel.send("An error occurred while stopping the event.");
    }
};

module.exports.names = {
    list: ["react", "stopr"]
};
