const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["changename", "usern", "تغييرالاسم"]
    },
    execute: async (client, message, args) => {
        try {
            // Check if the message is sent in a guild
            if (!message.guild) {
                return message.channel.send(strings.notInGuild);
            }

            // Check if the message author is allowed to manage the server
            if (!allowedUsers.includes(message.author.id)) {
                return message.channel.send(strings.noPermission);
            }

            // Prompt the user for the bot's password
            await message.channel.send(strings.passwordPrompt);

            const filter = m => m.author.id === message.author.id;
            const collector = message.channel.createMessageCollector({ filter, max: 1, time: 60000 });

            collector.on('collect', async collected => {
                const password = collected.content.trim();

                // Join the arguments to form the new username
                const newUsername = args.join(" ");

                // Check if the new username is provided and valid
                if (!newUsername || newUsername.length < 2 || newUsername.length > 32) {
                    return message.channel.send(strings.invalidUsername);
                }

                // Set the bot's username to the provided one using the password
                await client.user.setUsername(newUsername, password);

                // Send a confirmation message
                message.channel.send(strings.usernameChanged);
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    message.channel.send(strings.passwordTimeout);
                }
            });
        } catch (error) {
            // Log the error
            console.error("Error occurred while changing username:", error);

            // Send the error to the specified text channel
            const errorChannelId = '1221249421581226014'; // Replace with your error channel ID
            const errorChannel = client.channels.cache.get(errorChannelId);
            if (errorChannel && errorChannel.isText()) {
                errorChannel.send(`Error occurred while changing username: \`\`\`${error}\`\`\``);
            } else {
                console.error("Error channel not found or not a text channel.");
            }

            message.channel.send(strings.errorChangingUsername);
        }
    }
};
