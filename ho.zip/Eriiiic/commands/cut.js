const fs = require('fs');
const fastWords = require("../cut.json");
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Cut a text channel and send random messages from cut.json
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        const logChannel = client.channels.cache.get('1284204173772062815'); // Error/debugging log channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send("You don't have permission to use this command.");
        }

        // Ensure channel and number are provided
        if (args.length < 2) {
            return message.channel.send("Please provide a text channel and a number.");
        }

        // Validate the provided channel
        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            logChannel?.send(`Invalid channel: ${args[0]}`); // Log invalid channel
            return message.channel.send("Please provide a valid text channel.");
        }
        
        channel.send(`**السلام عليكم يلا كت ياحلوين؟ @here**`);

        // Validate the number of messages to send
        let num = parseInt(args[1]);
        if (isNaN(num) || num <= 0) {
            logChannel?.send(`Invalid number: ${args[1]}`); // Log invalid number
            return message.channel.send("Please provide a valid number.");
        }

        // Notify the user that the event has started
        message.channel.send(`**Starting to send cut messages in** ${channel.toString()}`);

        setTimeout(async () => {
            let usedMessages = new Set(); // Track used messages
            let availableMessages = fastWords.slice(); // Copy the messages

            // Function to send a random message
            const sendRandomMessage = async () => {
                // If we've used up all messages or reached the limit
                if (availableMessages.length === 0 || usedMessages.size >= num) {
                    logChannel?.send(`Finished sending ${usedMessages.size} messages.`); // Log completion
                    await channel.send(`**يعطيكم الف عافية على المشاركة انتهى الكت @here**`);
                    return;
                }

                // Select a random message and ensure it's unique
                const randomIndex = Math.floor(Math.random() * availableMessages.length);
                const randomMessage = availableMessages.splice(randomIndex, 1)[0];
                usedMessages.add(randomMessage);

                // Send the message to the channel
                await channel.send(`** (${randomMessage}) ||@here||**`);
                logChannel?.send(`Sent message: ${randomMessage}`); // Log sent message

                // Schedule the next message, if applicable
                if (usedMessages.size < num) {
                    setTimeout(sendRandomMessage, 35000); // Send a message every 35 seconds
                } else {
                    await channel.send(`**يعطيكم الف عافية على المشاركة انتهى الكت @here**`);
                }
            };

            // Log starting event
            logChannel?.send('Starting to send messages...');
            sendRandomMessage();
        }, 20000); // Wait 20 seconds before starting the event

    } catch (error) {
        console.error("Error occurred during the event:", error);

        // Log the error in the log channel and send an error message to the original channel
        const logChannel = client.channels.cache.get('1284204173772062815');
        logChannel?.send(`Error occurred during the cut event: \`\`\`${error.message}\`\`\``);
        message.channel.send("An error occurred while starting the event.");
    }
};

module.exports.names = {
    list: ["cut"]
};
